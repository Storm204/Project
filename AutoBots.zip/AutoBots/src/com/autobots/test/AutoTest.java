package com.autobots.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.autobots.pages.AutoPages;


public class AutoTest {
	AutoPages p;
	WebDriver driver;
	int counter=0;
	@BeforeClass
	public void first(){
	Driver dr = new Driver();
	driver=dr.getdriver();
	}
	/*public void browsers(String browsername)throws IOException{
		if(browsername.equalsIgnoreCase("firefox")){
			File src= new File("D:/dataservlet3.0/AutoBots/Config/Forms.property");
			FileInputStream fis = new FileInputStream(src);
			Properties pro = new Properties();
			pro.load(fis);
			driver = new FirefoxDriver();
			driver.get(pro.getProperty("URL"));
		}
		else if(browsername.equalsIgnoreCase("chrome")){
			File src= new File("D:/dataservlet3.0/AutoBots/Config/Forms.property");
			FileInputStream fis = new FileInputStream(src);
			Properties pro = new Properties();
			pro.load(fis);
			String chromePath = pro.getProperty("ChromeDriver");
			System.setProperty("webdriver.chrome.driver", chromePath);
			driver= new ChromeDriver();
			driver.get(pro.getProperty("URL"));
		}
		else if(browsername.equalsIgnoreCase("IE")){
			File src= new File("D:/dataservlet3.0/AutoBots/Config/Forms.property");
			FileInputStream fis = new FileInputStream(src);
			Properties pro = new Properties();
			pro.load(fis);
			String IEPath = pro.getProperty("IEDriver");
			System.setProperty("webdriver.ie.driver", IEPath);
			driver= new InternetExplorerDriver();
			driver.get(pro.getProperty("URL"));
		}
	}*/
	/*public  void ChromeStart() throws IOException
	{
		File src= new File("D:/dataservlet3.0/AutoBots/Config/Forms.property");
		FileInputStream fis = new FileInputStream(src);
		// to read the property file create an object of property class
		Properties pro = new Properties();
		// to load property file
		pro.load(fis);
		//to fetch the key value from property file
		String chromePath = pro.getProperty("ChromeDriver");
		//---------------Selenium Webdriver script----------------// to launch chrome
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver= new ChromeDriver();
		driver.get(pro.getProperty("URL"));
	}*/
	
	/*public  void FirefoxStart()
	{
		driver= new FirefoxDriver();
		driver.get("https://www.goibibo.com/");
	}*/
	
	
	@Test(priority=1)
	  public void testMethodRoundWay() throws Exception
	  {
	   
		AutoPages p = PageFactory.initElements(driver, AutoPages.class);

	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		
		p.Click(document.selectSingleNode(p.getXmlPath("roundtrip")).getText());
		Thread.sleep(1000);
	    p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
	    Thread.sleep(1000);
	    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
	    Thread.sleep(1000);
	    p.Click(document.selectSingleNode(p.getXmlPath("revert")).getText());
		Thread.sleep(1000);
	    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("openreturnCalendar")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("selectReturnDate")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("Traveller")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("Aplus")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("Cplus")).getText());
		Thread.sleep(1000);
		p.DropDown(document.selectSingleNode(p.getXmlPath("Class")).getText(), "B");
		 Thread.sleep(1000);
		 p.CheckBox(document.selectSingleNode(p.getXmlPath("setgo")).getText());
		 Thread.sleep(1000);
		 p.Click(document.selectSingleNode(p.getXmlPath("ticket1")).getText());
		   Thread.sleep(1000);
		 p.Click(document.selectSingleNode(p.getXmlPath("ticket2")).getText());
		   Thread.sleep(1000);
		 p.Click(document.selectSingleNode(p.getXmlPath("Tbook")).getText());
		   Thread.sleep(1000);
		  
		 
     }
	
	@Test(priority=2)
	public void Redirect()
	{
		driver.get("https://www.goibibo.com/");
	}
	
	@Test(priority=3)
	 public void testMethodOneWay() throws Exception
	  {
	   
	 p = PageFactory.initElements(driver, AutoPages.class);

	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		
	    p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
	    Thread.sleep(1000);
	    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
	    Thread.sleep(1000);
	    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("Traveller")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("Aplus")).getText());
		Thread.sleep(1000);
		p.Click(document.selectSingleNode(p.getXmlPath("Cplus")).getText());
		Thread.sleep(1000);
		p.DropDown(document.selectSingleNode(p.getXmlPath("Class")).getText(), "B");
		 Thread.sleep(1000);
		 p.CheckBox(document.selectSingleNode(p.getXmlPath("setgo")).getText());
		 Thread.sleep(1000);
		 p.Click(document.selectSingleNode(p.getXmlPath("Obook")).getText());
		   Thread.sleep(1000);
	    

   }
	@Test(priority=4)
	public void Redirect1()
	{
		driver.get("https://www.goibibo.com/");
	}
	
	
	@Test(priority=5)
	  public void NegativeTest() throws Exception
	  {
	   
		 p = PageFactory.initElements(driver, AutoPages.class);

	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		 
		 p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
		    Thread.sleep(1000);
		    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
		    Thread.sleep(1000);
		    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
			Thread.sleep(1000);
			p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
			Thread.sleep(1000);
			p.Click(document.selectSingleNode(p.getXmlPath("openreturnCalendar")).getText());
			Thread.sleep(1000);
			p.Click(document.selectSingleNode(p.getXmlPath("selectReturnDate")).getText());
			Thread.sleep(1000);
		
	    System.out.println("System fails when we try to book for one way trip as it automatically select to round trip");
   }
	
	
	
	@AfterClass
	public void Last() throws InterruptedException
	{
		p.initHtmlReport(counter);
		Thread.sleep(4000);
		driver.close();
	}
	
}
